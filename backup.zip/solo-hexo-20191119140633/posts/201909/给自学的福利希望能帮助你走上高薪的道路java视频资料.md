title: 给自学的福利，希望能帮助你走上高薪的道路（java视频资料）
date: '2019-09-18 17:04:08'
updated: '2019-09-18 17:05:05'
tags: [视频资料]
permalink: /articles/2019/09/18/1568797448008.html
---
![](https://img.hacpai.com/bing/20171227.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 一、前言

很多朋友想自学java但是出于不知道如何入手，不知道怎么去自学，下面我收集了视频资料，我相信你看完了，你就算是一个java初级工程师了，各位加油吧！

### 二、视频内容

00 讲义+笔记+资料  

01 语言基础+高级

02 JavaWeb+黑马旅游网

03 Mybatis

04 Spring

05 SpringMVC

06 Oracle

07 Maven高级

08 SSM整合案例【企业权限管理系统】

09 微服务电商【黑马乐优商城】（091 乐优商城(看这个，最新的)）

10 Lucene

11 Elasticsearch（选学）

12 Spring Data JPA

13 Spring Boot

14 Git

15 Vue

16 网络爬虫（选学）

17 Docker容器化

18 .持续集成与容器管理

19 微服务项目【学成在线】

20 Apache ServiceComb课程

21 容器化进阶K8S

22 华为云PaaS微服务治理课程（CSE Mesher开发）

23 微服务社交平台【十次方】

24 项目框架架构与优化

25 SaaS-IHRM项目

26 互联网全终端项目-好客租房项目

  

### 三、获取资料

公众号：回复"0018"领取资料
![868f42dcfd41c66b31d612af1309899d.gif](https://img.hacpai.com/file/2019/09/868f42dcfd41c66b31d612af1309899d-75acb481.gif)

