title: 我在 GitHub 上的开源项目
date: '2019-10-06 13:56:32'
updated: '2019-10-06 13:56:32'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [solo-blog](https://github.com/zywaiting/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/zywaiting/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zywaiting/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zywaiting/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://zhuyao.xin`](http://zhuyao.xin "项目主页")</span>

java经验总结 - 笑谈开发轶事<br/>品味程序人生



---

### 2. [RabbitMQ-SpringBoot2.x](https://github.com/zywaiting/RabbitMQ-SpringBoot2.x) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/zywaiting/RabbitMQ-SpringBoot2.x/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zywaiting/RabbitMQ-SpringBoot2.x/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zywaiting/RabbitMQ-SpringBoot2.x/network/members "分叉数")</span>

RabbitMQ与SpringBoot2.x框架的整合



---

### 3. [weChatBotMultiple](https://github.com/zywaiting/weChatBotMultiple) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/zywaiting/weChatBotMultiple/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zywaiting/weChatBotMultiple/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zywaiting/weChatBotMultiple/network/members "分叉数")</span>

多人



---

### 4. [wechatBotPublic](https://github.com/zywaiting/wechatBotPublic) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/zywaiting/wechatBotPublic/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zywaiting/wechatBotPublic/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zywaiting/wechatBotPublic/network/members "分叉数")</span>

微信公众号



---

### 5. [applet](https://github.com/zywaiting/applet) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/zywaiting/applet/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zywaiting/applet/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zywaiting/applet/network/members "分叉数")</span>

小程序后台接口



---

### 6. [java](https://github.com/zywaiting/java) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/zywaiting/java/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zywaiting/java/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zywaiting/java/network/members "分叉数")</span>

java



---

### 7. [guo](https://github.com/zywaiting/guo) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/zywaiting/guo/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zywaiting/guo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zywaiting/guo/network/members "分叉数")</span>

小郭



---

### 8. [wechatBot](https://github.com/zywaiting/wechatBot) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/zywaiting/wechatBot/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zywaiting/wechatBot/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zywaiting/wechatBot/network/members "分叉数")</span>

微信机器人



---

### 9. [springcloud](https://github.com/zywaiting/springcloud) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/zywaiting/springcloud/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zywaiting/springcloud/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zywaiting/springcloud/network/members "分叉数")</span>





---

### 10. [bus](https://github.com/zywaiting/bus) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/zywaiting/bus/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zywaiting/bus/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zywaiting/bus/network/members "分叉数")</span>

实时公交

